const express = require('express');
const { NodeSSH } = require('node-ssh');
const WebSocket = require('ws');

const app = express();
const PORT = 3000;

app.use(express.static('public'));

const ssh = new NodeSSH();
const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});

const wss = new WebSocket.Server({ server });

wss.on('connection', (ws) => {
    let sshConnection;
    
    const connectSSH = async () => {
        try {
            sshConnection = await ssh.connect({
                host: '165.232.167.117',
                username: 'root',
                password: 'hokage1234'
            });
            
            const shell = await sshConnection.requestShell();
            
            shell.on('data', (data) => {
                ws.send(data.toString());
            });
            
            ws.on('message', (message) => {
                shell.write(message.toString());
            });
            
            ws.on('close', () => {
                shell.end();
                sshConnection.dispose();
            });
            
        } catch (err) {
            ws.send(`\r\nSSH Connection Error: ${err.message}\r\n`);
            ws.close();
        }
    };
    
    connectSSH();
});