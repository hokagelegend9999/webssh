<?php
require __DIR__ . '/vendor/autoload.php';

use phpseclib3\Net\SSH2;

$host = "165.232.167.117";
$username = "root";  // Lebih baik gunakan variabel $username daripada hardcode di login()
$password = "hokage1234";  // Ganti nama variabel dari $root_password ke $password

// Inisialisasi SSH
$ssh = new SSH2('165.232.167.117', 200); // Coba port alternatif
echo "Membuat objek SSH...<br>";

if (!$ssh->login($username, $password)) {
    echo "<h2>Gagal Login</h2>";
    echo "Error: " . $ssh->getLastError() . "<br>";
    echo "Log: " . $ssh->getLog() . "<br>";
    die();
}

echo "<h2>Berhasil Login!</h2>";

// Test beberapa perintah
$commands = [
    'pwd' => "Current directory",
    'ls -la' => "List files",
    'uname -a' => "System info",
    'df -h' => "Disk space"  // Menambahkan perintah untuk contoh
];

foreach ($commands as $cmd => $desc) {
    echo "<h3>$desc ($cmd)</h3>";
    $output = $ssh->exec($cmd);
    echo "<pre>" . htmlspecialchars($output) . "</pre>";
    echo "<hr>";
}

// Tutup koneksi (tidak wajib tetapi baik untuk dilakukan)
unset($ssh);
?>