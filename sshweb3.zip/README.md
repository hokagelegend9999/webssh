# webssh

Install PHP 

##
EXKEKUSI PHP : php -S localhost:8000
