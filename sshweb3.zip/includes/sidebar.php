<style>
    /* Sidebar Styles */
    .sidebar {
        width: 250px;
        background-color: white;
        box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
        position: fixed;
        height: 100vh;
        padding-top: 80px;
        z-index: 999;
        transition: all 0.3s ease;
    }
    
    .sidebar-menu {
        list-style: none;
        padding: 1rem 0;
    }
    
    .sidebar-item {
        margin-bottom: 0.5rem;
    }
    
    .sidebar-link {
        display: flex;
        align-items: center;
        padding: 0.75rem 1.5rem;
        color: var(--gray);
        text-decoration: none;
        transition: all 0.3s ease;
        border-left: 3px solid transparent;
    }
    
    .sidebar-link:hover, .sidebar-link.active {
        background-color: rgba(67, 97, 238, 0.1);
        color: var(--primary);
        border-left: 3px solid var(--primary);
    }
    
    .sidebar-link i {
        margin-right: 0.75rem;
        font-size: 1.1rem;
        width: 20px;
        text-align: center;
    }
    
    .submenu {
        list-style: none;
        padding-left: 2.5rem;
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.3s ease;
    }
    
    .submenu.show {
        max-height: 500px;
    }
    
    .submenu-link {
        display: flex;
        align-items: center;
        padding: 0.5rem 1rem;
        color: var(--gray);
        text-decoration: none;
        transition: all 0.3s ease;
        font-size: 0.9rem;
    }
    
    .submenu-link:hover {
        color: var(--primary);
    }
    
    .has-submenu {
        position: relative;
    }
    
    .submenu-toggle {
        position: absolute;
        right: 1rem;
        transition: transform 0.3s ease;
    }
    
    .submenu-toggle.rotate {
        transform: rotate(90deg);
    }
    
    .main-content {
        margin-left: 250px;
        padding: 100px 2rem 2rem;
        width: calc(100% - 250px);
        min-height: 100vh;
    }
</style>

<div class="sidebar">
    <ul class="sidebar-menu">
        <li class="sidebar-item">
            <a href="dashboard.php" class="sidebar-link active">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
        </li>
        
        <li class="sidebar-item">
            <a href="terminal.php" class="sidebar-link">
                <i class="fas fa-terminal"></i>
                <span>Terminal</span>
            </a>
        </li>
        
        <li class="sidebar-item">
            <a href="users.php" class="sidebar-link">
                <i class="fas fa-users"></i>
                <span>Jumlah User</span>
            </a>
        </li>
        
        <li class="sidebar-item has-submenu">
            <a href="#" class="sidebar-link" id="xray-menu">
                <i class="fas fa-project-diagram"></i>
                <span>Xray</span>
                <i class="fas fa-chevron-right submenu-toggle"></i>
            </a>
            <ul class="submenu" id="xray-submenu">
                <li>
                    <a href="xray-vmess.php" class="submenu-link">
                        <i class="fas fa-code-branch"></i>
                        <span>Vmess</span>
                    </a>
                </li>
                <li>
                    <a href="xray-vless.php" class="submenu-link">
                        <i class="fas fa-ethernet"></i>
                        <span>Vless</span>
                    </a>
                </li>
                <li>
                    <a href="xray-trojan.php" class="submenu-link">
                        <i class="fas fa-shield-alt"></i>
                        <span>Trojan</span>
                    </a>
                </li>
                <li>
                    <a href="xray-grpc.php" class="submenu-link">
                        <i class="fas fa-stream"></i>
                        <span>gRPC</span>
                    </a>
                </li>
            </ul>
        </li>
        
        <li class="sidebar-item">
            <a href="ssh-ws.php" class="sidebar-link">
                <i class="fas fa-plug"></i>
                <span>SSH Websocket</span>
            </a>
        </li>
        
        <li class="sidebar-item">
            <a href="shadowsocks.php" class="sidebar-link">
                <i class="fas fa-user-secret"></i>
                <span>Shadowsocks</span>
            </a>
        </li>
        
        <li class="sidebar-item">
            <a href="performance.php" class="sidebar-link">
                <i class="fas fa-chart-line"></i>
                <span>Performance</span>
            </a>
        </li>
        
        <li class="sidebar-item">
            <a href="settings.php" class="sidebar-link">
                <i class="fas fa-cog"></i>
                <span>Settings</span>
            </a>
        </li>
        
        <li class="sidebar-item">
            <a href="security.php" class="sidebar-link">
                <i class="fas fa-shield-alt"></i>
                <span>Security</span>
            </a>
        </li>
    </ul>
</div>

<script>
    // Toggle submenus
    document.getElementById('xray-menu').addEventListener('click', function(e) {
        e.preventDefault();
        const submenu = document.getElementById('xray-submenu');
        const toggleIcon = this.querySelector('.submenu-toggle');
        
        submenu.classList.toggle('show');
        toggleIcon.classList.toggle('rotate');
    });
</script>