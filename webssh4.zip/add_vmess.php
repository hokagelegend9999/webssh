<?php
$host = "165.232.167.117";
$username = "root";
$password = "hokage1234";

// Fungsi UUID lokal jika remote gagal
function generate_uuid_v4() {
    $data = random_bytes(16);
    $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
    $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

// Ambil data dari form dan sanitasi
$user = preg_replace('/[^a-zA-Z0-9_.-]/', '', $_POST['user']);
$masaaktif = intval($_POST['masaaktif'] ?? 30);
$iplim = intval($_POST['iplim'] ?? 0);
$quota = intval($_POST['quota'] ?? 0);
$domain = $_SERVER['SERVER_NAME'] ?? 'example.com';

$iplim = $iplim > 0 ? $iplim : 9999;
$quota = $quota > 0 ? $quota : 9999;
$quota_bytes = $quota * 1024 * 1024 * 1024;
$exp = date('Y-m-d', strtotime("+$masaaktif days"));

// Koneksi SSH
$connection = ssh2_connect($host, 22);
if (!$connection || !ssh2_auth_password($connection, $username, $password)) {
    die("❌ Koneksi SSH atau autentikasi gagal");
}

// Coba ambil UUID dari server
$uuid_stream = ssh2_exec($connection, 'cat /proc/sys/kernel/random/uuid');
stream_set_blocking($uuid_stream, true);
$uuid = trim(stream_get_contents($uuid_stream));

// Gunakan UUID lokal jika gagal
if (!$uuid) {
    $uuid = generate_uuid_v4();
}

// Eksekusi perintah di server: simpan IP/Quota, edit config.json
ssh2_exec($connection, "mkdir -p /etc/vmess");
ssh2_exec($connection, "echo $iplim > /etc/vmess/{$user}IP");
ssh2_exec($connection, "echo $quota_bytes > /etc/vmess/{$user}");

$add_cmd = <<<EOD
uuid=$uuid && \
exp=$exp && \
user=$user && \
json_line=',{"id": "'\$uuid'","alterId": 0,"email": "'\$user'"}' && \
sed -i "/#vmess\$/a\\#vm \$user \$exp\$json_line" /etc/xray/config.json && \
sed -i "/#vmessgrpc\$/a\\#vmg \$user \$exp \$uuid\$json_line" /etc/xray/config.json
EOD;

ssh2_exec($connection, $add_cmd);
ssh2_exec($connection, "systemctl restart xray");

// Ambil jumlah akun VMess dan debug config entry
$check_stream = ssh2_exec($connection, "grep -c -E '^#vmg ' /etc/xray/config.json");
stream_set_blocking($check_stream, true);
$vmess_count = trim(stream_get_contents($check_stream));

$debug_stream = ssh2_exec($connection, "grep -A 2 '#vmg $user' /etc/xray/config.json");
stream_set_blocking($debug_stream, true);
$debug_output = trim(stream_get_contents($debug_stream));

// Buat link VMess
$vmess_ws = [
    'v' => '2', 'ps' => $user, 'add' => $domain, 'port' => '443',
    'id' => $uuid, 'aid' => '0', 'net' => 'ws', 'path' => '/vmess',
    'type' => 'none', 'host' => $domain, 'tls' => 'tls'
];

$vmess_ntls = $vmess_ws;
$vmess_ntls['port'] = '80';
$vmess_ntls['tls'] = 'none';

$vmess_grpc = [
    'v' => '2', 'ps' => $user, 'add' => $domain, 'port' => '443',
    'id' => $uuid, 'aid' => '0', 'net' => 'grpc', 'path' => 'vmess-grpc',
    'type' => 'none', 'host' => $domain, 'tls' => 'tls'
];

$vmess_opok = $vmess_ntls;
$vmess_opok['path'] = 'http://tsel.me/worryfree';
$vmess_opok['host'] = 'tsel.me';

$vmesslink1 = 'vmess://' . base64_encode(json_encode($vmess_ws));
$vmesslink2 = 'vmess://' . base64_encode(json_encode($vmess_ntls));
$vmesslink3 = 'vmess://' . base64_encode(json_encode($vmess_grpc));
$vmesslink4 = 'vmess://' . base64_encode(json_encode($vmess_opok));

// Buat file YAML OpenClash
$yaml_content = <<<EOT
Link TLS   : {$vmesslink1}
Link NTLS  : {$vmesslink2}
Link gRPC  : {$vmesslink3}
Link OPOK  : {$vmesslink4}
EOT;

file_put_contents("/home/vps/public_html/vmess-{$user}.txt", $yaml_content);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Hasil Generate VMess</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary: #4361ee;
            --primary-dark: #3a56d4;
            --secondary: #3f37c9;
            --success: #4cc9f0;
            --dark: #212529;
            --light: #f8f9fa;
            --gray: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 2rem;
            color: var(--dark);
        }
        
        .container {
            max-width: 900px;
            margin: 0 auto;
        }
        
        .card {
            background: white;
            border-radius: var(--border-radius);
            padding: 2.5rem;
            box-shadow: var(--box-shadow);
            position: relative;
            overflow: hidden;
            margin-bottom: 2rem;
        }
        
        .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 6px;
            height: 100%;
            background: linear-gradient(to bottom, var(--primary), var(--success));
        }
        
        .card-header {
            display: flex;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        
        .success-badge {
            background: linear-gradient(135deg, var(--success), var(--primary));
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            font-size: 1rem;
        }
        
        .success-badge i {
            margin-right: 8px;
            font-size: 1.1rem;
        }
        
        .account-info {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .info-item {
            background: var(--light);
            padding: 1rem;
            border-radius: var(--border-radius);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.03);
        }
        
        .info-label {
            font-size: 0.8rem;
            color: var(--gray);
            margin-bottom: 0.3rem;
            display: flex;
            align-items: center;
        }
        
        .info-label i {
            margin-right: 6px;
            font-size: 0.9rem;
        }
        
        .info-value {
            font-weight: 600;
            font-size: 1.1rem;
            color: var(--dark);
            word-break: break-all;
        }
        
        .section-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin: 1.5rem 0 1rem;
            display: flex;
            align-items: center;
            color: var(--primary);
        }
        
        .section-title i {
            margin-right: 10px;
        }
        
        .debug-box {
            background: #f8f9fa;
            border-left: 4px solid var(--primary);
            padding: 1rem;
            border-radius: 0 var(--border-radius) var(--border-radius) 0;
            font-family: 'Courier New', monospace;
            font-size: 0.9rem;
            overflow-x: auto;
            margin-bottom: 1.5rem;
        }
        
        .links-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .link-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 1rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            border: 1px solid #e9ecef;
            transition: var(--transition);
        }
        
        .link-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            border-color: var(--primary);
        }
        
        .link-type {
            font-size: 0.8rem;
            color: var(--gray);
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }
        
        .link-type i {
            margin-right: 6px;
        }
        
        .link-value {
            font-weight: 500;
            font-size: 0.9rem;
            color: var(--dark);
            word-break: break-all;
            margin-bottom: 0.8rem;
        }
        
        .copy-btn {
            background: var(--primary);
            color: white;
            border: none;
            padding: 0.4rem 0.8rem;
            border-radius: 4px;
            font-size: 0.8rem;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
        }
        
        .copy-btn i {
            margin-right: 5px;
        }
        
        .copy-btn:hover {
            background: var(--primary-dark);
        }
        
        .file-path {
            background: var(--light);
            padding: 0.8rem 1rem;
            border-radius: var(--border-radius);
            font-family: 'Courier New', monospace;
            font-size: 0.9rem;
            display: inline-block;
            margin-top: 0.5rem;
        }
        
        @media (max-width: 768px) {
            .card {
                padding: 1.5rem;
            }
            
            .account-info {
                grid-template-columns: 1fr;
            }
            
            .links-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <div class="success-badge">
                    <i class="fas fa-check-circle"></i> Akun VMess Berhasil Dibuat!
                </div>
            </div>
            
            <div class="account-info">
                <div class="info-item">
                    <div class="info-label">
                        <i class="fas fa-user"></i> Username
                    </div>
                    <div class="info-value"><?= htmlspecialchars($user) ?></div>
                </div>
                
                <div class="info-item">
                    <div class="info-label">
                        <i class="fas fa-fingerprint"></i> UUID
                    </div>
                    <div class="info-value"><?= $uuid ?></div>
                </div>
                
                <div class="info-item">
                    <div class="info-label">
                        <i class="fas fa-calendar-times"></i> Expired
                    </div>
                    <div class="info-value"><?= $exp ?></div>
                </div>
                
                <div class="info-item">
                    <div class="info-label">
                        <i class="fas fa-lock"></i> IP Limit
                    </div>
                    <div class="info-value"><?= $iplim ?> IP</div>
                </div>
                
                <div class="info-item">
                    <div class="info-label">
                        <i class="fas fa-database"></i> Quota
                    </div>
                    <div class="info-value"><?= $quota ?> GB</div>
                </div>
                
                <div class="info-item">
                    <div class="info-label">
                        <i class="fas fa-globe"></i> Domain
                    </div>
                    <div class="info-value"><?= $domain ?></div>
                </div>
                
                <div class="info-item">
                    <div class="info-label">
                        <i class="fas fa-users"></i> Total Akun
                    </div>
                    <div class="info-value"><?= $vmess_count ?></div>
                </div>
            </div>
            
            <div class="section-title">
                <i class="fas fa-search"></i> Debug Config Entry
            </div>
            <div class="debug-box"><?= htmlspecialchars($debug_output) ?></div>
            
            <div class="section-title">
                <i class="fas fa-link"></i> Link VMess
            </div>
            <div class="links-grid">
                <div class="link-card">
                    <div class="link-type">
                        <i class="fas fa-shield-alt"></i> TLS
                    </div>
                    <div class="link-value" id="link1"><?= $vmesslink1 ?></div>
                    <button class="copy-btn" onclick="copyToClipboard('link1')">
                        <i class="far fa-copy"></i> Copy Link
                    </button>
                </div>
                
                <div class="link-card">
                    <div class="link-type">
                        <i class="fas fa-unlock"></i> Non-TLS
                    </div>
                    <div class="link-value" id="link2"><?= $vmesslink2 ?></div>
                    <button class="copy-btn" onclick="copyToClipboard('link2')">
                        <i class="far fa-copy"></i> Copy Link
                    </button>
                </div>
                
                <div class="link-card">
                    <div class="link-type">
                        <i class="fas fa-bolt"></i> gRPC
                    </div>
                    <div class="link-value" id="link3"><?= $vmesslink3 ?></div>
                    <button class="copy-btn" onclick="copyToClipboard('link3')">
                        <i class="far fa-copy"></i> Copy Link
                    </button>
                </div>
                
                <div class="link-card">
                    <div class="link-type">
                        <i class="fas fa-mobile-alt"></i> Opok
                    </div>
                    <div class="link-value" id="link4"><?= $vmesslink4 ?></div>
                    <button class="copy-btn" onclick="copyToClipboard('link4')">
                        <i class="far fa-copy"></i> Copy Link
                    </button>
                </div>
            </div>
            
            <div class="section-title">
                <i class="fas fa-file-alt"></i> File YAML
            </div>
            <div class="file-path">/home/vps/public_html/vmess-<?= $user ?>.txt</div>
        </div>
    </div>

    <script>
        function copyToClipboard(elementId) {
            const element = document.getElementById(elementId);
            const text = element.innerText;
            
            navigator.clipboard.writeText(text).then(() => {
                const buttons = document.querySelectorAll('.copy-btn');
                buttons.forEach(btn => {
                    if (btn.getAttribute('onclick').includes(elementId)) {
                        const originalText = btn.innerHTML;
                        btn.innerHTML = '<i class="fas fa-check"></i> Copied!';
                        btn.style.background = '#2ecc71';
                        
                        setTimeout(() => {
                            btn.innerHTML = originalText;
                            btn.style.background = '';
                        }, 2000);
                    }
                });
            }).catch(err => {
                console.error('Failed to copy: ', err);
            });
        }
    </script>
</body>
</html>