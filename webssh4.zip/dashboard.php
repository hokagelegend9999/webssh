<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: index.php");
    exit();
}

set_include_path(get_include_path() . PATH_SEPARATOR . 'phpseclib');
include('Net/SSH2.php');

$host = "165.232.167.117";
$root_password = "hokage1234";

$ssh = new Net_SSH2($host);
if (!$ssh->login('root', $root_password)) {
    $status = "Failed to connect to server";
    $status_class = "danger";
} else {
    $status = "Connected to server";
    $status_class = "success";
}

$username = $_SESSION['username'];

// Execute command if submitted
if (isset($_POST['command'])) {
    $command = $_POST['command'];
    $output = $ssh->exec($command);
}
?>

<?php include('includes/header.php'); ?>
<?php include('includes/sidebar.php'); ?>

<main class="main-content">
    <style>
        /* Dashboard Content Styles */
        .card {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            padding-bottom: 0.75rem;
            border-bottom: 1px solid var(--gray-light);
        }
        
        .card-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--dark);
        }
        
        .status-badge {
            padding: 0.35rem 0.75rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .badge-success {
            background-color: rgba(76, 201, 240, 0.1);
            color: var(--success);
        }
        
        .badge-danger {
            background-color: rgba(247, 37, 133, 0.1);
            color: var(--danger);
        }
        
        .command-form {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .command-input {
            flex: 1;
            padding: 0.75rem 1rem;
            border: 1px solid var(--gray-light);
            border-radius: 5px;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }
        
        .command-input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 5px;
            font-size: 0.9rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background-color: var(--primary);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: var(--primary-dark);
        }
        
        .output-container {
            background-color: var(--dark);
            color: #00ff00;
            padding: 1rem;
            border-radius: 5px;
            font-family: 'Courier New', monospace;
            overflow-x: auto;
            max-height: 400px;
            overflow-y: auto;
        }
        
        .quick-commands {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .quick-command {
            background-color: white;
            border-radius: 5px;
            padding: 1rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid var(--gray-light);
        }
        
        .quick-command:hover {
            background-color: var(--primary);
            color: white;
            transform: translateY(-3px);
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
        }
        
        .quick-command i {
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
        }
        
        .server-stats {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background-color: white;
            border-radius: 10px;
            padding: 1.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
        }
        
        .stat-info h3 {
            font-size: 1rem;
            color: var(--gray);
            margin-bottom: 0.25rem;
        }
        
        .stat-info p {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--dark);
        }
        
        .icon-primary {
            background-color: rgba(67, 97, 238, 0.1);
            color: var(--primary);
        }
        
        .icon-success {
            background-color: rgba(76, 201, 240, 0.1);
            color: var(--success);
        }
        
        .icon-warning {
            background-color: rgba(248, 150, 30, 0.1);
            color: var(--warning);
        }
        
        .icon-danger {
            background-color: rgba(247, 37, 133, 0.1);
            color: var(--danger);
        }
    </style>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Welcome, <?php echo htmlspecialchars($username); ?>!</h2>
            <span class="status-badge badge-<?php echo $status_class; ?>">
                <i class="fas fa-circle"></i> <?php echo $status; ?>
            </span>
        </div>
        <p>You are now managing your VPS server. Use the terminal below to execute commands.</p>
    </div>

    <div class="server-stats">
        <div class="stat-card">
            <div class="stat-icon icon-primary">
                <i class="fas fa-microchip"></i>
            </div>
            <div class="stat-info">
                <h3>CPU Usage</h3>
                <p>25%</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-success">
                <i class="fas fa-memory"></i>
            </div>
            <div class="stat-info">
                <h3>Memory</h3>
                <p>3.2/8GB</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-warning">
                <i class="fas fa-hdd"></i>
            </div>
            <div class="stat-info">
                <h3>Disk Space</h3>
                <p>120/250GB</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-danger">
                <i class="fas fa-network-wired"></i>
            </div>
            <div class="stat-info">
                <h3>Bandwidth</h3>
                <p>2.4TB</p>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Quick Commands</h2>
        </div>
        <div class="quick-commands">
            <div class="quick-command" onclick="setCommand('uname -a')">
                <i class="fas fa-info-circle"></i>
                <p>System Info</p>
            </div>
            <div class="quick-command" onclick="setCommand('df -h')">
                <i class="fas fa-database"></i>
                <p>Disk Usage</p>
            </div>
            <div class="quick-command" onclick="setCommand('top -n 1 -b')">
                <i class="fas fa-tasks"></i>
                <p>Running Processes</p>
            </div>
            <div class="quick-command" onclick="setCommand('free -m')">
                <i class="fas fa-memory"></i>
                <p>Memory Usage</p>
            </div>
            <div class="quick-command" onclick="setCommand('netstat -tuln')">
                <i class="fas fa-plug"></i>
                <p>Network Ports</p>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Terminal</h2>
        </div>
        <form method="POST" class="command-form">
            <input type="text" name="command" id="command" class="command-input" placeholder="Enter command..." required>
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-paper-plane"></i> Execute
            </button>
        </form>
        
        <?php if (isset($output)): ?>
        <div class="output-container">
            <pre><?php echo htmlspecialchars($output); ?></pre>
        </div>
        <?php endif; ?>
    </div>
</main>

<script>
    function setCommand(cmd) {
        document.getElementById('command').value = cmd;
    }
</script>

</body>
</html>