<?php
// SSH Account Creator for Ubuntu Server with License Verification
$host = "165.232.167.117";
$root_password = "hokage1234";

// Function to execute SSH commands
function ssh_exec($host, $user, $pass, $command) {
    $connection = ssh2_connect($host, 200);
    if (!$connection) {
        return false;
    }
    
    if (!ssh2_auth_password($connection, $user, $pass)) {
        return false;
    }
    
    $stream = ssh2_exec($connection, $command);
    stream_set_blocking($stream, true);
    $output = stream_get_contents($stream);
    fclose($stream);
    
    return $output;
}

// Function to check license from GitHub
function check_license($ip) {
    $license_url = "https://raw.githubusercontent.com/hokagelegend9999/gas/refs/heads/main/izin.txt";
    $license_file = @file_get_contents($license_url);
    
    if (empty($license_file)) {
        return ['status' => false, 'message' => "Failed to fetch license data"];
    }
    
    $lines = explode("\n", $license_file);
    foreach ($lines as $line) {
        $line = trim(preg_replace('/[^[:print:]]/', '', $line));
        if (empty($line)) continue;
        
        $fields = preg_split('/\s+/', $line);
        if (count($fields) < 4) continue;
        
        if ($fields[3] == $ip) {
            $client_name = $fields[1] ?? '';
            $exp_date = preg_replace('/[^0-9-]/', '', $fields[2] ?? '');
            
            if (!preg_match('/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$/', $exp_date)) {
                return ['status' => false, 'message' => "Invalid date format: $exp_date"];
            }
            
            $current_epoch = time();
            $exp_epoch = strtotime($exp_date);
            
            if ($exp_epoch === false) {
                return ['status' => false, 'message' => "Invalid date: $exp_date"];
            }
            
            if ($exp_epoch < $current_epoch) {
                return ['status' => false, 'message' => "License has expired"];
            }
            
            $days_remaining = floor(($exp_epoch - $current_epoch) / 86400);
            return [
                'status' => true,
                'client_name' => $client_name,
                'exp_date' => $exp_date,
                'days_remaining' => $days_remaining
            ];
        }
    }
    
    return ['status' => false, 'message' => "IP not registered in license"];
}

// Function to create SSH account
function create_ssh_account($username, $password, $expiry_days, $iplimit) {
    global $host, $root_password;
    
    // First check if user exists and is expired
    $check_user = ssh_exec($host, 'root', $root_password, "id -u $username 2>/dev/null");
    if (!empty($check_user)) {
        $exp_check = ssh_exec($host, 'root', $root_password, "chage -l $username | grep 'Account expires' | awk -F': ' '{print \$2}'");
        $exp_date = trim($exp_check);
        
        if ($exp_date != 'never') {
            $exp_epoch = strtotime($exp_date);
            $current_epoch = time();
            
            if ($exp_epoch < $current_epoch) {
                // Delete expired user
                ssh_exec($host, 'root', $root_password, "userdel -r $username >/dev/null 2>&1");
                ssh_exec($host, 'root', $root_password, "sed -i '/^### $username /d' /etc/xray/ssh");
                ssh_exec($host, 'root', $root_password, "rm -f /etc/xray/sshx/${username}IP /home/vps/public_html/ssh-$username.txt");
            } else {
                return ['status' => false, 'message' => "Username $username is still active until $exp_date"];
            }
        }
    }
    
    // Generate expiry date
    $expiry_date = date('Y-m-d', strtotime("+$expiry_days days"));
    
    // Command to create user with expiry date
    $commands = [
        "useradd -e $expiry_date -M -s /bin/false $username",
        "echo '$username:$password' | chpasswd",
        "echo \"$iplimit\" > /etc/xray/sshx/$username-IP",
        "echo \"### $username $expiry_date $password\" >> /etc/xray/ssh",
        "mkdir -p /etc/xray/sshx/akun",
        "mkdir -p /home/vps/public_html"
    ];
    
    // Create account info file
    $domain = ssh_exec($host, 'root', $root_password, "cat /etc/xray/domain");
    $isp = ssh_exec($host, 'root', $root_password, "cat /etc/xray/isp");
    $city = ssh_exec($host, 'root', $root_password, "cat /etc/xray/city");
    $slowdns_domain = ssh_exec($host, 'root', $root_password, "cat /etc/xray/dns");
    $slowdns_key = ssh_exec($host, 'root', $root_password, "cat /etc/slowdns/server.pub");
    
    $account_info = generate_account_info($username, $password, $expiry_days, $iplimit, 
                                        trim($domain), trim($isp), trim($city), 
                                        trim($slowdns_domain), trim($slowdns_key));
    
    $commands[] = "cat > /home/vps/public_html/ssh-$username.txt <<-END
$account_info
END";
    
    foreach ($commands as $cmd) {
        $result = ssh_exec($host, 'root', $root_password, $cmd);
        if ($result === false) {
            return ['status' => false, 'message' => "Failed to execute command: $cmd"];
        }
    }
    
    return ['status' => true, 'message' => "Account created successfully", 'info' => $account_info];
}

// Function to generate account info
function generate_account_info($username, $password, $expiry_days, $iplimit, $domain, $isp, $city, $slowdns_domain, $slowdns_key) {
    $expiry_date = date('Y-m-d', strtotime("+$expiry_days days"));
    
    $info = "
◇━━━━━━━━━━━━━━━━━◇
SSH Premium Account
◇━━━━━━━━━━━━━━━━━◇
Username        : $username
Password        : $password
Expired On      : $expiry_date
◇━━━━━━━━━━━━━━━━━◇
ISP             : $isp
City            : $city
Host            : $domain
Login Limit     : $iplimit IP
Port OpenSSH    : 22
Port Dropbear   : 109, 143
Port SSH WS     : 80, 8080
Port SSH SSL WS : 443
Port SSL/TLS    : 8443, 8880
Port OVPN WS SSL: 2086
Port OVPN SSL   : 990
Port OVPN TCP   : 1194
Port OVPN UDP   : 2200
Proxy Squid     : 3128
BadVPN UDP      : 7100, 7300
◇━━━━━━━━━━━━━━━━━◇
SSH UDP VIRAL   : $domain:1-65535@$username:$password
◇━━━━━━━━━━━━━━━━━◇
HTTP COSTUM WS  : $domain:80@$username:$password
◇━━━━━━━━━━━━━━━━━◇
Host Slowdns    : $slowdns_domain
Port Slowdns    : 80, 443, 53
Pub Key         : $slowdns_key
◇━━━━━━━━━━━━━━━━━◇
Payload WS/WSS  :
GET / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: ws[crlf][crlf]
◇━━━━━━━━━━━━━━━━━◇
OpenVPN SSL     : http://$domain:89/ssl.ovpn
OpenVPN TCP     : http://$domain:89/tcp.ovpn
OpenVPN UDP     : http://$domain:89/udp.ovpn
◇━━━━━━━━━━━━━━━━━◇
Save Link Account: http://$domain:89/ssh-$username.txt
◇━━━━━━━━━━━━━━━━━◇
";
    
    return $info;
}

// Main execution
$license_checked = false;
$license_info = [];
$account_created = false;
$account_info = '';
$error = '';

// Check license if not already done
if (!$license_checked) {
    $ip = ssh_exec($host, 'root', $root_password, "curl -s ifconfig.me");
    if ($ip === false) {
        $error = "Failed to get server IP";
    } else {
        $license_info = check_license(trim($ip));
        if (!$license_info['status']) {
            $error = "License check failed: " . $license_info['message'];
        } else {
            $license_checked = true;
        }
    }
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $license_checked) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $expiry_days = $_POST['expiry_days'] ?? 30;
    $iplimit = 3; // Fixed to 3 and cannot be changed
    
    // Validate inputs
    if (empty($username) || empty($password)) {
        $error = "Username and password are required!";
    } elseif (!preg_match('/^[a-zA-Z0-9_.-]+$/', $username)) {
        $error = "Username contains invalid characters!";
    } else {
        // Create account
        $result = create_ssh_account($username, $password, $expiry_days, $iplimit);
        if ($result['status']) {
            $account_created = true;
            $account_info = $result['info'];
        } else {
            $error = $result['message'];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PREMIUM SSH WEBSOCKET | BUAT AKUN</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #6c5ce7;
            --secondary: #a29bfe;
            --dark: #2d3436;
            --light: #f5f6fa;
            --accent: #fd79a8;
            --success: #00b894;
            --warning: #fdcb6e;
            --danger: #d63031;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa, #e4e8f0);
            color: var(--dark);
            min-height: 100vh;
            background-attachment: fixed;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        .glass-card {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            padding: 2rem;
            margin-bottom: 2rem;
        }
        
        h1 {
            font-size: 2.5rem;
            margin-bottom: 1.5rem;
            background: linear-gradient(to right, var(--primary), var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-align: center;
            position: relative;
            padding-bottom: 1rem;
        }
        
        h1::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 3px;
            background: linear-gradient(to right, var(--primary), var(--accent));
            border-radius: 3px;
        }
        
        .btn-back {
            display: inline-flex;
            align-items: center;
            background: rgba(108, 92, 231, 0.2);
            color: var(--primary);
            padding: 0.7rem 1.5rem;
            border-radius: 50px;
            text-decoration: none;
            margin-bottom: 2rem;
            transition: all 0.3s ease;
            border: 1px solid var(--primary);
        }
        
        .btn-back:hover {
            background: var(--primary);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.4);
        }
        
        .btn-back i {
            margin-right: 8px;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--dark);
        }
        
        input, select {
            width: 100%;
            padding: 1rem;
            border-radius: 10px;
            border: none;
            background: rgba(255, 255, 255, 0.9);
            color: var(--dark);
            font-size: 1rem;
            transition: all 0.3s ease;
            border: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        input:focus, select:focus {
            outline: none;
            border-color: var(--primary);
            background: rgba(255, 255, 255, 1);
            box-shadow: 0 0 0 3px rgba(108, 92, 231, 0.3);
        }
        
        button[type="submit"] {
            width: 100%;
            padding: 1rem;
            border-radius: 10px;
            border: none;
            background: linear-gradient(45deg, var(--primary), var(--accent));
            color: white;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 1rem;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.4);
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        button[type="submit"]:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(108, 92, 231, 0.6);
        }
        
        button[type="submit"]:disabled {
            background: gray;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        
        .error {
            background: rgba(214, 48, 49, 0.2);
            border-left: 4px solid var(--danger);
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1.5rem;
            color: #d63031;
        }
        
        .success {
            background: rgba(0, 184, 148, 0.2);
            border-left: 4px solid var(--success);
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1.5rem;
            color: #00b894;
        }
        
        .account-info-container {
            position: relative;
            margin-top: 2rem;
        }
        
        .account-info {
            background: rgba(255, 255, 255, 0.95);
            padding: 1.5rem;
            border-radius: 10px;
            white-space: pre-wrap;
            font-family: 'Courier New', monospace;
            overflow-x: auto;
            border: 1px solid rgba(0, 0, 0, 0.1);
            color: #333;
            position: relative;
            line-height: 1.6;
        }
        
        .copy-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background: var(--primary);
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            z-index: 10;
        }
        
        .copy-btn:hover {
            background: var(--accent);
            transform: translateY(-2px);
        }
        
        .copy-btn.copied {
            background: var(--success);
        }
        
        .copy-btn.copied::after {
            content: 'Copied!';
            position: absolute;
            right: 100%;
            margin-right: 10px;
            background: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 0.3rem 0.6rem;
            border-radius: 5px;
            font-size: 0.8rem;
            white-space: nowrap;
        }
        
        .iplimit-display {
            background: rgba(253, 121, 168, 0.2);
            color: var(--accent);
            padding: 1rem;
            border-radius: 10px;
            font-weight: bold;
            text-align: center;
            margin: 0.5rem 0;
            border: 1px solid var(--accent);
        }
        
        .form-note {
            font-size: 0.9rem;
            color: var(--dark);
            margin-top: 0.5rem;
            opacity: 0.8;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                padding: 1rem;
            }
            
            h1 {
                font-size: 2rem;
            }
            
            .glass-card {
                padding: 1.5rem;
            }
            
            .copy-btn {
                padding: 0.5rem;
                font-size: 0.8rem;
            }
        }
        
        /* Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .glass-card {
            animation: fadeIn 0.6s ease-out;
        }
        
        /* Floating particles background */
        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            overflow: hidden;
        }
        
        .particle {
            position: absolute;
            background: rgba(108, 92, 231, 0.5);
            border-radius: 50%;
            animation: float linear infinite;
        }
        
        @keyframes float {
            0% { transform: translateY(0) rotate(0deg); }
            100% { transform: translateY(-100vh) rotate(360deg); }
        }
    </style>
</head>
<body>
<?php include('includes/header.php'); ?>
<?php include('includes/sidebar.php'); ?>
    <!-- Floating particles background -->
    <div class="particles" id="particles"></div>
    
    <div class="container">
        <a href="menu.php" class="btn-back"><i class="fas fa-arrow-left"></i> Kembali ke Menu</a>
        
        <div class="glass-card">
            <h1><i class="fas fa-key"></i> BUAT AKUN SSH WEBSOCKET</h1>
            
            <?php if (!empty($error)): ?>
                <div class="error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <form method="post" <?php echo !$license_checked ? 'class="disabled-form"' : ''; ?>>
                <div class="form-group">
                    <label for="username"><i class="fas fa-user"></i> Username:</label>
                    <input type="text" id="username" name="username" required placeholder="Masukkan username">
                </div>
                
                <div class="form-group">
                    <label for="password"><i class="fas fa-lock"></i> Password:</label>
                    <input type="text" id="password" name="password" required placeholder="Masukkan password">
                </div>
                
                <div class="form-group">
                    <label for="expiry_days"><i class="fas fa-calendar-alt"></i> Masa Aktif:</label>
                    <select id="expiry_days" name="expiry_days">
                        <option value="1">1 Hari</option>
                        <option value="7">7 Hari</option>
                        <option value="30" selected>30 Hari</option>
                        <option value="60">60 Hari</option>
                        <option value="90">90 Hari</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-network-wired"></i> Limit IP:</label>
                    <div class="iplimit-display">3</div>
                    <input type="hidden" name="iplimit" value="3">
                    <p class="form-note">*Limit IP tidak dapat diubah dan tetap 3</p>
                </div>
                
                <button type="submit" <?php echo !$license_checked ? 'disabled' : ''; ?>>
                    <i class="fas fa-plus-circle"></i> BUAT AKUN
                </button>
            </form>
        </div>
        
        <?php if ($account_created): ?>
            <div class="glass-card">
                <div class="success">
                    <i class="fas fa-check-circle"></i> Akun berhasil dibuat!
                </div>
                <div class="account-info-container">
                    <button class="copy-btn" id="copyBtn">
                        <i class="fas fa-copy"></i> Copy
                    </button>
                    <div class="account-info" id="accountInfo">
                        <?php echo nl2br(htmlspecialchars($account_info)); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // Create floating particles
        document.addEventListener('DOMContentLoaded', function() {
            const particlesContainer = document.getElementById('particles');
            const particleCount = 30;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.classList.add('particle');
                
                // Random size between 1px and 3px
                const size = Math.random() * 2 + 1;
                particle.style.width = `${size}px`;
                particle.style.height = `${size}px`;
                
                // Random position
                particle.style.left = `${Math.random() * 100}vw`;
                particle.style.top = `${Math.random() * 100}vh`;
                
                // Random animation duration between 50s and 150s
                const duration = Math.random() * 100 + 50;
                particle.style.animationDuration = `${duration}s`;
                
                // Random delay
                particle.style.animationDelay = `${Math.random() * 30}s`;
                
                particlesContainer.appendChild(particle);
            }
        });

        // Copy button functionality
        document.getElementById('copyBtn')?.addEventListener('click', function() {
            const accountInfo = document.getElementById('accountInfo');
            const range = document.createRange();
            range.selectNode(accountInfo);
            window.getSelection().removeAllRanges();
            window.getSelection().addRange(range);
            
            try {
                const successful = document.execCommand('copy');
                if (successful) {
                    const btn = document.getElementById('copyBtn');
                    btn.classList.add('copied');
                    setTimeout(() => {
                        btn.classList.remove('copied');
                    }, 2000);
                }
            } catch(err) {
                console.log('Unable to copy');
            }
            
            window.getSelection().removeAllRanges();
        });
    </script>
</body>
</html>