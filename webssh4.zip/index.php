<?php
session_start();  // Mulai session untuk mengelola login

set_include_path(get_include_path() . PATH_SEPARATOR . 'phpseclib');
include('Net/SSH2.php');

// setting VPS
$host = "165.232.167.117";
$root_password = "hokage1234";

// Mengecek apakah form login sudah disubmit
if (isset($_POST['login_username']) && isset($_POST['login_password'])) {
    // mendapatkan data dari form login
    $login_username = $_POST['login_username'];
    $login_password = $_POST['login_password'];

    // Memastikan data tidak kosong
    if (!empty($login_username) && !empty($login_password)) {
        // Membuat koneksi SSH untuk login
        $ssh = new Net_SSH2($host);
        if (!$ssh->login('root', $root_password)) {
            $login_error = "Login gagal. Periksa kredensial Anda.";
        } else {
            // Menyimpan username ke session setelah login sukses
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $login_username; // Menyimpan username dalam session
            
            // Redirect ke dashboard
            header("Location: dashboard.php");
            exit;
        }
    } else {
        $login_error = "Username dan password login tidak boleh kosong.";
    }
}

// Mengecek apakah form pendaftaran user baru sudah disubmit
if (isset($_POST['register_username']) && isset($_POST['register_password'])) {
    // mendapatkan data dari form pendaftaran
    $register_username = $_POST['register_username'];
    $register_password = $_POST['register_password'];

    // Memastikan data tidak kosong
    if (!empty($register_username) && !empty($register_password)) {
        // Membuat koneksi SSH untuk menambahkan user baru
        $ssh = new Net_SSH2($host);
        if (!$ssh->login('root', $root_password)) {
            $register_error = "Koneksi server gagal.";
        } else {
            // Menambahkan user baru
            $ssh->exec("useradd $register_username");

            // Mengatur password untuk user baru
            $ssh->exec("echo '$register_password' | passwd --stdin $register_username");

            // Memberikan feedback
            $register_success = "User '$register_username' berhasil didaftarkan!";
        }
    } else {
        $register_error = "Username dan password pendaftaran tidak boleh kosong.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Access Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4cc9f0;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4bb543;
            --error-color: #ff3333;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .container {
            display: flex;
            max-width: 1000px;
            width: 100%;
            background: white;
            border-radius: 15px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .illustration {
            flex: 1;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 40px;
            color: white;
        }
        
        .illustration img {
            max-width: 100%;
            height: auto;
        }
        
        .illustration h2 {
            margin-top: 20px;
            font-weight: 600;
            text-align: center;
        }
        
        .form-container {
            flex: 1;
            padding: 50px;
        }
        
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .logo i {
            font-size: 40px;
            color: var(--primary-color);
        }
        
        .logo h1 {
            font-size: 24px;
            font-weight: 600;
            margin-top: 10px;
            color: var(--dark-color);
        }
        
        .tabs {
            display: flex;
            margin-bottom: 30px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .tab {
            padding: 10px 20px;
            cursor: pointer;
            font-weight: 500;
            color: #777;
            transition: all 0.3s ease;
        }
        
        .tab.active {
            color: var(--primary-color);
            border-bottom: 2px solid var(--primary-color);
        }
        
        .form {
            display: none;
        }
        
        .form.active {
            display: block;
            animation: fadeIn 0.5s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .form h2 {
            margin-bottom: 20px;
            font-weight: 600;
            color: var(--dark-color);
        }
        
        .input-group {
            margin-bottom: 20px;
            position: relative;
        }
        
        .input-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark-color);
        }
        
        .input-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        
        .input-group input:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
            outline: none;
        }
        
        .btn {
            width: 100%;
            padding: 12px;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn:hover {
            background: var(--secondary-color);
            transform: translateY(-2px);
        }
        
        .message {
            margin-top: 20px;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
        }
        
        .success {
            background-color: rgba(75, 181, 67, 0.2);
            color: var(--success-color);
        }
        
        .error {
            background-color: rgba(255, 51, 51, 0.2);
            color: var(--error-color);
        }
        
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            
            .illustration {
                padding: 30px;
            }
            
            .form-container {
                padding: 30px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="illustration">
            <i class="fas fa-shield-alt" style="font-size: 80px; margin-bottom: 20px;"></i>
            <h2>Secure Access Portal</h2>
            <p style="text-align: center; margin-top: 10px; opacity: 0.8;">Manage your server access with enhanced security</p>
        </div>
        
        <div class="form-container">
            <div class="logo">
                <i class="fas fa-server"></i>
                <h1>Server Management</h1>
            </div>
            
            <div class="tabs">
                <div class="tab active" onclick="switchTab('login')">Login</div>
                <div class="tab" onclick="switchTab('register')">Register</div>
            </div>
            
            <div id="login-form" class="form active">
                <h2>Welcome Back</h2>
                <?php if(isset($login_error)): ?>
                    <div class="message error"><?php echo $login_error; ?></div>
                <?php endif; ?>
                
                <form action="index.php" method="POST">
                    <div class="input-group">
                        <label for="login_username">Username</label>
                        <input type="text" id="login_username" name="login_username" placeholder="Enter your username" required>
                    </div>
                    
                    <div class="input-group">
                        <label for="login_password">Password</label>
                        <input type="password" id="login_password" name="login_password" placeholder="Enter your password" required>
                    </div>
                    
                    <button type="submit" class="btn">Sign In</button>
                </form>
            </div>
            
            <div id="register-form" class="form">
                <h2>Create New Account</h2>
                <?php if(isset($register_error)): ?>
                    <div class="message error"><?php echo $register_error; ?></div>
                <?php endif; ?>
                <?php if(isset($register_success)): ?>
                    <div class="message success"><?php echo $register_success; ?></div>
                <?php endif; ?>
                
                <form action="index.php" method="POST">
                    <div class="input-group">
                        <label for="register_username">Username</label>
                        <input type="text" id="register_username" name="register_username" placeholder="Choose a username" required>
                    </div>
                    
                    <div class="input-group">
                        <label for="register_password">Password</label>
                        <input type="password" id="register_password" name="register_password" placeholder="Create a password" required>
                    </div>
                    
                    <button type="submit" class="btn">Register</button>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        function switchTab(tabName) {
            // Hide all forms
            document.querySelectorAll('.form').forEach(form => {
                form.classList.remove('active');
            });
            
            // Remove active class from all tabs
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Show selected form and mark tab as active
            document.getElementById(tabName + '-form').classList.add('active');
            event.currentTarget.classList.add('active');
        }
    </script>
</body>
</html>