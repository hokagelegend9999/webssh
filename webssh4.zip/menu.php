<?php 
include('includes/header.php'); 
include('includes/sidebar.php');

// Server credentials
$host = "165.232.167.117";
$username = "root";
$password = "hokage1234";

// Function to execute SSH commands
function executeSSHCommand($host, $username, $password, $command) {
    if (!function_exists('ssh2_connect')) {
        die("SSH2 extension not installed. Please install php-ssh2 extension.");
    }
    
    $connection = ssh2_connect($host, 200);
    if (!$connection) {
        return false;
    }
    
    if (!ssh2_auth_password($connection, $username, $password)) {
        return false;
    }
    
    $stream = ssh2_exec($connection, $command);
    stream_set_blocking($stream, true);
    $output = stream_get_contents($stream);
    fclose($stream);
    
    ssh2_disconnect($connection);
    
    return trim($output);
}

// Get system information
$ssh = function($cmd) use ($host, $username, $password) {
    return executeSSHCommand($host, $username, $password, $cmd);
};

$system = [
    'os' => $ssh("lsb_release -ds | sed 's/\"//g'"),
    'memory' => $ssh("free -h | awk '/Mem:/ {print $3 \"/\" $2}'"),
    'cpu' => $ssh("nproc") . " Cores | " . 
            $ssh("top -bn1 | awk '/Cpu/ {printf \"%.1f%%\", 100 - $8}'"),
    'uptime' => $ssh("uptime -p | cut -d ' ' -f 2-"),
    'domain' => $ssh("cat /etc/xray/domain 2>/dev/null || echo 'Not Set'")
];

$services = [
    'xray' => strpos($ssh("systemctl status xray"), 'running') !== false ? 'ON' : 'OFF',
    'nginx' => strpos($ssh("systemctl status nginx"), 'running') !== false ? 'ON' : 'OFF',
    'dropbear' => strpos($ssh("/etc/init.d/dropbear status"), 'running') !== false ? 'ON' : 'OFF',
    'ssh_ws' => strpos($ssh("systemctl status ws-stunnel"), 'running') !== false ? 'ON' : 'OFF'
];

$accounts = [
    'ssh' => $ssh("grep -c -E '^### ' /etc/xray/ssh"),
    'vmess' => $ssh("grep -c -E '^#vmg ' /etc/xray/config.json"),
    'vless' => $ssh("grep -c -E '^#vlg ' /etc/xray/config.json"),
    'trojan' => $ssh("grep -c -E '^#trg ' /etc/xray/config.json")
];

$traffic = [
    'today' => $ssh("vnstat -i {$ssh("vnstat | sed -n '3p' | awk '{print $1}' | grep -o '[^:]*'")} | grep today | awk '{print $8 \" \" $9}'"),
    'yesterday' => $ssh("vnstat -i {$ssh("vnstat | sed -n '3p' | awk '{print $1}' | grep -o '[^:]*'")} | grep yesterday | awk '{print $8 \" \" $9}'"),
    'month' => $ssh("vnstat -i {$ssh("vnstat | sed -n '3p' | awk '{print $1}' | grep -o '[^:]*'")} | grep -E '$(date +%b) [0-9]{2}' | awk '{print $9 \" \" $10}'")
];

$ipinfo = [
    'ip' => $ssh("curl -s4 ifconfig.me"),
    'isp' => $ssh("curl -s ipinfo.io/org | cut -d ' ' -f 2-10"),
    'city' => $ssh("curl -s ipinfo.io/city")
];

$license = [
    'client' => 'HOKAGE LEGEND',
    'days_left' => 365,
    'exp_date' => date('Y-m-d', strtotime('+1 year'))
];
?>

<link rel="stylesheet" href="style.css">

<div class="main-content">
    <div class="page-header">
        <h1 class="page-title">Server Status Dashboard</h1>
        <div class="page-actions">
            <button class="btn btn-refresh" onclick="location.reload()">
                <i class="fas fa-sync-alt"></i> Refresh
            </button>
        </div>
    </div>

    <div class="dashboard-grid">
        <!-- System Overview Card -->
        <div class="card card-system">
            <div class="card-header">
                <h3><i class="fas fa-server"></i> System Overview</h3>
            </div>
            <div class="card-body">
                <div class="info-row">
                    <span class="info-label">OS:</span>
                    <span class="info-value"><?= htmlspecialchars($system['os']) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Memory:</span>
                    <span class="info-value"><?= htmlspecialchars($system['memory']) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">CPU:</span>
                    <span class="info-value"><?= htmlspecialchars($system['cpu']) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Uptime:</span>
                    <span class="info-value"><?= htmlspecialchars($system['uptime']) ?></span>
                </div>
            </div>
        </div>

        <!-- Network Info Card -->
        <div class="card card-network">
            <div class="card-header">
                <h3><i class="fas fa-network-wired"></i> Network Info</h3>
            </div>
            <div class="card-body">
                <div class="info-row">
                    <span class="info-label">IP:</span>
                    <span class="info-value"><?= htmlspecialchars($ipinfo['ip']) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">ISP:</span>
                    <span class="info-value"><?= htmlspecialchars($ipinfo['isp']) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">City:</span>
                    <span class="info-value"><?= htmlspecialchars($ipinfo['city']) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Domain:</span>
                    <span class="info-value"><?= htmlspecialchars($system['domain']) ?></span>
                </div>
            </div>
        </div>

        <!-- Services Status Card -->
        <div class="card card-services">
            <div class="card-header">
                <h3><i class="fas fa-cogs"></i> Services Status</h3>
            </div>
            <div class="card-body">
                <div class="status-grid">
                    <div class="status-item <?= strtolower($services['xray']) ?>">
                        <i class="fas fa-project-diagram"></i>
                        <span>XRAY</span>
                        <span class="status-badge"><?= $services['xray'] ?></span>
                    </div>
                    <div class="status-item <?= strtolower($services['nginx']) ?>">
                        <i class="fas fa-globe"></i>
                        <span>NGINX</span>
                        <span class="status-badge"><?= $services['nginx'] ?></span>
                    </div>
                    <div class="status-item <?= strtolower($services['dropbear']) ?>">
                        <i class="fas fa-shield-alt"></i>
                        <span>DROPBEAR</span>
                        <span class="status-badge"><?= $services['dropbear'] ?></span>
                    </div>
                    <div class="status-item <?= strtolower($services['ssh_ws']) ?>">
                        <i class="fas fa-plug"></i>
                        <span>SSH WS</span>
                        <span class="status-badge"><?= $services['ssh_ws'] ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Account Stats Card -->
        <div class="card card-accounts">
            <div class="card-header">
                <h3><i class="fas fa-users"></i> Account Statistics</h3>
            </div>
            <div class="card-body">
                <div class="stats-grid">
                    <div class="stat-item">
                        <div class="stat-value"><?= htmlspecialchars($accounts['ssh']) ?></div>
                        <div class="stat-label">SSH Users</div>
                        <div class="stat-icon">
                            <i class="fas fa-terminal"></i>
                        </div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value"><?= htmlspecialchars($accounts['vmess']) ?></div>
                        <div class="stat-label">VMess</div>
                        <div class="stat-icon">
                            <i class="fas fa-bolt"></i>
                        </div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value"><?= htmlspecialchars($accounts['vless']) ?></div>
                        <div class="stat-label">VLess</div>
                        <div class="stat-icon">
                            <i class="fas fa-tachometer-alt"></i>
                        </div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value"><?= htmlspecialchars($accounts['trojan']) ?></div>
                        <div class="stat-label">Trojan</div>
                        <div class="stat-icon">
                            <i class="fas fa-lock"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Traffic Monitoring Card -->
        <div class="card card-traffic">
            <div class="card-header">
                <h3><i class="fas fa-chart-line"></i> Traffic Monitoring</h3>
            </div>
            <div class="card-body">
                <div class="traffic-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Period</th>
                                <th>Usage</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Today</td>
                                <td><?= htmlspecialchars($traffic['today']) ?></td>
                            </tr>
                            <tr>
                                <td>Yesterday</td>
                                <td><?= htmlspecialchars($traffic['yesterday']) ?></td>
                            </tr>
                            <tr>
                                <td>This Month</td>
                                <td><?= htmlspecialchars($traffic['month']) ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Quick Actions Card -->
        <div class="card card-actions">
            <div class="card-header">
                <h3><i class="fas fa-rocket"></i> Quick Actions</h3>
            </div>
            <div class="card-body">
                <div class="actions-grid">
                    <a href="form_add_user.php" class="action-btn">
                        <i class="fas fa-terminal"></i>
                        <span>SSH VPN</span>
                    </a>
                    <a href="vmess_account.php" class="action-btn">
                        <i class="fas fa-bolt"></i>
                        <span>VMess</span>
                        </a>
                    <button class="action-btn" data-modal="vless-modal">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>VLess</span>
                    </button>
                    <button class="action-btn" data-modal="trojan-modal">
                        <i class="fas fa-lock"></i>
                        <span>Trojan</span>
                    </button>
                    <button class="action-btn" data-modal="backup-modal">
                        <i class="fas fa-archive"></i>
                        <span>Backup</span>
                    </button>
                    <button class="action-btn" data-modal="running-modal">
                        <i class="fas fa-play-circle"></i>
                        <span>Running</span>
                    </button>
                    <button class="action-btn" onclick="restartServices()">
                        <i class="fas fa-redo"></i>
                        <span>Restart</span>
                    </button>
                    <button class="action-btn" onclick="rebootServer()">
                        <i class="fas fa-power-off"></i>
                        <span>Reboot</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- License Info Footer -->
    <div class="license-footer">
        <div class="license-info">
            <span><i class="fas fa-user"></i> <?= htmlspecialchars($license['client']) ?></span>
            <span><i class="fas fa-calendar-check"></i> Expires: <?= htmlspecialchars($license['exp_date']) ?></span>
            <span><i class="fas fa-clock"></i> Days Left: <?= htmlspecialchars($license['days_left']) ?></span>
        </div>
        <div class="version-info">
            <span>HOKAGE LEGEND STORE</span>
            <span>v1.0.0</span>
        </div>
    </div>
</div>

<!-- Modal Templates -->
<div id="ssh-modal" class="modal">
    <div class="modal-content">
        <span class="close-modal">&times;</span>
        <h3><i class="fas fa-terminal"></i> SSH VPN Management</h3>
        <div class="modal-body">
            <p>SSH user management functionality will appear here.</p>
        </div>
    </div>
</div>
<div id="restart-modal" class="modal">
    <div class="modal-content">
        <span class="close-modal">&times;</span>
        <h3><i class="fas fa-redo"></i> Restarting Services</h3>
        <div class="modal-body">
            <div class="restart-progress">
                <div class="progress-container">
                    <div class="progress-header">
                        <span>Service</span>
                        <span>Status</span>
                    </div>
                    <div id="service-progress">
                        <!-- Progress items will be added here by JavaScript -->
                    </div>
                    <div class="progress-summary">
                        <div class="progress-bar-container">
                            <div id="overall-progress" class="progress-bar"></div>
                        </div>
                        <span id="progress-text">0% Complete</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
// Modal functionality
document.querySelectorAll('[data-modal]').forEach(btn => {
    btn.addEventListener('click', function() {
        const modalId = this.getAttribute('data-modal');
        const modal = document.getElementById(modalId);
        modal.style.display = 'block';
    });
});

document.querySelectorAll('.close-modal').forEach(btn => {
    btn.addEventListener('click', function() {
        this.closest('.modal').style.display = 'none';
    });
});

window.addEventListener('click', function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
});

function restartServices() {
    if(confirm('Are you sure you want to restart all services?')) {
        const modal = document.getElementById('restart-modal');
        modal.style.display = 'block';
        
        // Clear previous progress
        document.getElementById('service-progress').innerHTML = '';
        
        // Services to restart with their display names
        const services = [
            { name: 'System Daemon', command: 'daemon-reload', icon: 'fas fa-cogs' },
            { name: 'NGINX', command: 'nginx', icon: 'fas fa-globe' },
            { name: 'XRAY', command: 'xray', icon: 'fas fa-project-diagram' },
            { name: 'RC-Local', command: 'rc-local', icon: 'fas fa-code' },
            { name: 'Client', command: 'client', icon: 'fas fa-desktop' },
            { name: 'Server', command: 'server', icon: 'fas fa-server' },
            { name: 'WS-Dropbear', command: 'ws-dropbear', icon: 'fas fa-shield-alt' },
            { name: 'WebSocket', command: 'ws', icon: 'fas fa-plug' },
            { name: 'OpenVPN', command: 'openvpn', icon: 'fas fa-network-wired' },
            { name: 'Cron', command: 'cron', icon: 'fas fa-clock' },
            { name: 'HAProxy', command: 'haproxy', icon: 'fas fa-random' },
            { name: 'Netfilter', command: 'netfilter-persistent', icon: 'fas fa-filter' },
            { name: 'Squid', command: 'squid', icon: 'fas fa-water' },
            { name: 'UDP Custom', command: 'udp-custom', icon: 'fas fa-broadcast-tower' },
            { name: 'WS-Stunnel', command: 'ws-stunnel', icon: 'fas fa-lock' },
            { name: 'BadVPN 1', command: 'badvpn1', icon: 'fas fa-vr-cardboard' },
            { name: 'BadVPN 2', command: 'badvpn2', icon: 'fas fa-vr-cardboard' },
            { name: 'BadVPN 3', command: 'badvpn3', icon: 'fas fa-vr-cardboard' },
            { name: 'KYT', command: 'kyt', icon: 'fas fa-shield-virus' }
        ];

        // Create progress items
        services.forEach((service, index) => {
            const progressItem = document.createElement('div');
            progressItem.className = 'progress-item';
            progressItem.id = `service-${index}`;
            progressItem.innerHTML = `
                <div class="service-info">
                    <i class="${service.icon}"></i>
                    <span>${service.name}</span>
                </div>
                <div class="service-status">
                    <span class="status-text">Pending</span>
                    <div class="status-icon">
                        <i class="fas fa-circle-notch fa-spin"></i>
                    </div>
                </div>
            `;
            document.getElementById('service-progress').appendChild(progressItem);
        });

        // Start the restart process
        restartServicesSequentially(services, 0);
    }
}

function restartServicesSequentially(services, index) {
    if (index >= services.length) {
        // All services completed
        document.getElementById('progress-text').textContent = '100% Complete - All services restarted!';
        setTimeout(() => {
            location.reload();
        }, 2000);
        return;
    }

    const service = services[index];
    const progressItem = document.getElementById(`service-${index}`);
    const statusText = progressItem.querySelector('.status-text');
    const statusIcon = progressItem.querySelector('.status-icon i');

    // Update progress bar
    const percentComplete = Math.floor((index / services.length) * 100);
    document.getElementById('overall-progress').style.width = `${percentComplete}%`;
    document.getElementById('progress-text').textContent = `${percentComplete}% Complete`;

    // Make AJAX call to restart this service
    fetch('restart_service.php?service=' + service.command)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                statusText.textContent = 'Restarted';
                statusText.style.color = '#4CAF50';
                statusIcon.className = 'fas fa-check-circle';
                statusIcon.style.color = '#4CAF50';
            } else {
                statusText.textContent = 'Failed: ' + data.error;
                statusText.style.color = '#F44336';
                statusIcon.className = 'fas fa-times-circle';
                statusIcon.style.color = '#F44336';
            }

            // Process next service
            setTimeout(() => {
                restartServicesSequentially(services, index + 1);
            }, 500);
        })
        .catch(error => {
            statusText.textContent = 'Error';
            statusText.style.color = '#F44336';
            statusIcon.className = 'fas fa-times-circle';
            statusIcon.style.color = '#F44336';
            
            // Continue with next service even if one fails
            setTimeout(() => {
                restartServicesSequentially(services, index + 1);
            }, 500);
        });
}

function rebootServer() {
    if(confirm('WARNING: This will reboot the server. Continue?')) {
        alert('Server rebooting...');
        // AJAX call to reboot server
    }
}
</script>

<?php include('includes/footer.php'); ?>