<?php
header('Content-Type: application/json');

// Server credentials
$host = "165.232.167.117";
$username = "root";
$password = "hokage1234";

// Get service from query parameter
$service = $_GET['service'] ?? '';

// Function to execute SSH commands
function executeSSHCommand($host, $username, $password, $command) {
    if (!function_exists('ssh2_connect')) {
        return ['success' => false, 'error' => 'SSH2 extension not installed'];
    }
    
    $connection = ssh2_connect($host, 200);
    if (!$connection) {
        return ['success' => false, 'error' => 'Connection failed'];
    }
    
    if (!ssh2_auth_password($connection, $username, $password)) {
        return ['success' => false, 'error' => 'Authentication failed'];
    }
    
    $stream = ssh2_exec($connection, "systemctl restart $command");
    stream_set_blocking($stream, true);
    $output = stream_get_contents($stream);
    $errorStream = ssh2_fetch_stream($stream, SSH2_STREAM_STDERR);
    $errorOutput = stream_get_contents($errorStream);
    fclose($stream);
    
    ssh2_disconnect($connection);
    
    if (!empty($errorOutput)) {
        return ['success' => false, 'error' => trim($errorOutput)];
    }
    
    return ['success' => true];
}

// Validate service
if (empty($service)) {
    echo json_encode(['success' => false, 'error' => 'No service specified']);
    exit;
}

// Execute the restart command
$result = executeSSHCommand($host, $username, $password, $service);

echo json_encode($result);
?>