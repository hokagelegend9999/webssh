<?php
// =============================================
// BASIC CONFIGURATION (MUST BE AT TOP)
// =============================================
declare(strict_types=1);
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

// =============================================
// NAMESPACE IMPORTS (MUST COME NEXT)
// =============================================
use phpseclib3\Net\SFTP;
use phpseclib3\Crypt\PublicKeyLoader;

// =============================================
// CONSTANTS AND CONFIGURATION
// =============================================
const DEBUG_LOG = 'debug.log';
const ALLOWED_FILES = [
    'm-tcp', 'm-theme', 'm-trojan', 'm-', 'm-vless', 'm-vmess',
    'menu', 'skt-auto-backup', 'skt-auto-restore', 'skt-cekservice',
    'skt-check-port', 'skt-manual-backup', 'skt-manual-restore',
    'skt-menu-backup', 'skt-running', 'skt-sshws', 'skt-system',
    'tendang', 'trial', 'trialssh', 'trialtrojan', 'trialvless',
    'trialvmess', 'update', 'xraylimit'
];

// =============================================
// HELPER FUNCTIONS
// =============================================
function log_debug(string $message): void {
    $timestamp = date('Y-m-d H:i:s');
    $backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2);
    $caller = $backtrace[1]['function'] ?? 'main';
    file_put_contents(DEBUG_LOG, "[$timestamp][$caller] $message\n", FILE_APPEND);
}

function format_size(int $bytes): string {
    if ($bytes >= 1073741824) return number_format($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576) return number_format($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024) return number_format($bytes / 1024, 2) . ' KB';
    return $bytes . ' bytes';
}

function get_file_icon(string $filename): string {
    $icons = [
        'm-' => 'fas fa-cog',
        'skt-' => 'fas fa-tools',
        'trial' => 'fas fa-stopwatch',
        'menu' => 'fas fa-bars',
        'update' => 'fas fa-sync-alt'
    ];
    
    foreach ($icons as $prefix => $icon) {
        if (strpos($filename, $prefix) === 0) return $icon;
    }
    return 'fas fa-file';
}

// =============================================
// MAIN EXECUTION
// =============================================
try {
    // Initialize debug log
    file_put_contents(DEBUG_LOG, "[" . date('Y-m-d H:i:s') . "] Script started\n");
    log_debug("Starting execution");

    // Check required files
    $required_files = [
        'vendor/autoload.php' => 'PHP SecLib',
        'includes/header.php' => 'Header template',
        'includes/sidebar.php' => 'Sidebar template',
        'includes/footer.php' => 'Footer template'
    ];

    foreach ($required_files as $file => $desc) {
        if (!file_exists($file)) {
            throw new RuntimeException("Missing required file: $file ($desc)");
        }
    }

    // Load dependencies
    require_once 'vendor/autoload.php';
    log_debug("Dependencies loaded");

    // Load templates
    require_once 'includes/header.php';
    require_once 'includes/sidebar.php';

    // SFTP Configuration
    $config = [
        'host' => '165.232.167.117',
        'username' => 'root',
        'password' => 'hokage1234',
        'directory' => '/usr/bin'
    ];

    // Establish SFTP connection
    log_debug("Attempting SFTP connection");
    $sftp = new SFTP($config['host']);
    if (!$sftp->login($config['username'], $config['password'])) {
        throw new RuntimeException('SFTP login failed');
    }
    log_debug("SFTP connection established");

    // Get directory listing
    $files = $sftp->nlist($config['directory'], true);
    if ($files === false) {
        throw new RuntimeException('Failed to list directory contents');
    }
    log_debug("Found " . count($files) . " items in directory");

    // Filter and sort files
    $filteredFiles = array_filter($files, fn($file) => in_array($file, ALLOWED_FILES));
    sort($filteredFiles, SORT_NATURAL | SORT_FLAG_CASE);
    log_debug(count($filteredFiles) . " files after filtering");

    // Display results
    ?>
    <div class="main-content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-header">
                    <h5>Directory: <?= htmlspecialchars($config['directory']) ?></h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Icon</th>
                                    <th>Name</th>
                                    <th>Type</th>
                                    <th>Size</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($filteredFiles)): ?>
                                    <tr><td colspan="5" class="text-center">No files found</td></tr>
                                <?php else: ?>
                                    <?php foreach ($filteredFiles as $file): ?>
                                        <?php
                                        $fullPath = $config['directory'] . '/' . $file;
                                        $isDir = $sftp->is_dir($fullPath);
                                        $icon = $isDir ? 'fas fa-folder text-warning' : get_file_icon($file);
                                        $type = $isDir ? 'Directory' : 'File';
                                        $size = $isDir ? '-' : format_size($sftp->filesize($fullPath));
                                        ?>
                                        <tr>
                                            <td><i class="<?= $icon ?> fa-lg"></i></td>
                                            <td><?= htmlspecialchars($file) ?></td>
                                            <td><span class="badge badge-<?= $isDir ? 'warning' : 'primary' ?>"><?= $type ?></span></td>
                                            <td><?= $size ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-outline-primary" onclick="viewFile('<?= htmlspecialchars($file) ?>')">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <button class="btn btn-sm btn-outline-success" onclick="downloadFile('<?= htmlspecialchars($file) ?>')">
                                                    <i class="fas fa-download"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    function viewFile(filename) {
        alert('View functionality would show: ' + filename);
        // Actual implementation would use AJAX to fetch file content
    }

    function downloadFile(filename) {
        alert('Download functionality would fetch: ' + filename);
        // Actual implementation would trigger file download
    }
    </script>
    <?php

    // Load footer
    require_once 'includes/footer.php';

} catch (Exception $e) {
    // Error handling
    log_debug("ERROR: " . $e->getMessage());
    ?>
    <div class="alert alert-danger">
        <h4>Error Occurred</h4>
        <p><?= htmlspecialchars($e->getMessage()) ?></p>
        <pre class="mt-3 p-3 bg-light"><?= htmlspecialchars($e->getTraceAsString()) ?></pre>
    </div>
    <?php
    if (file_exists('includes/footer.php')) {
        require_once 'includes/footer.php';
    }
}