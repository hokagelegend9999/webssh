<!DOCTYPE html>
<html>
<head>
    <title>Tambah Akun VMess</title>
    <style>
        body { font-family: Arial; margin: 40px; background: #f5f5f5; }
        form { background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px #ccc; max-width: 400px; }
        input[type=text], input[type=number] {
            width: 100%; padding: 8px; margin: 8px 0; box-sizing: border-box;
        }
        input[type=submit] {
            background-color: #28a745; color: white; padding: 10px;
            border: none; border-radius: 5px; cursor: pointer;
        }
        pre { background: #eee; padding: 10px; border-radius: 5px; margin-top: 20px; }
    </style>
</head>
<body>

<h2>Tambah Akun VMess</h2>

<form method="post" action="add_vmess.php">
    <label>Username:</label>
    <input type="text" name="user" required>

    <label>Masa Aktif (hari):</label>
    <input type="number" name="masaaktif" value="10" required>

    <label>Batas IP (0 = unlimited):</label>
    <input type="number" name="iplim" value="0" required>

    <label>Quota (GB, 0 = unlimited):</label>
    <input type="number" name="quota" value="0" required>

    <input type="submit" value="Buat Akun">
</form>

</body>
</html>
